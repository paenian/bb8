Converted to MP3 from Jens SFX Pack 2 BB-8 Sphero Sounds

I 'normalized' most tracks, making their peak at 0db because I need loud sounds when I go to cons.  For many of them I also normalized sections within the clip to be louder, those are tagged - Louder.

The MP3s are 128kbps because that works well enough with MP3 Triggers. 

Some folks don't like the maxed out peaks because they want to mix stuff.  They should maybe look at Jens raw wav files, however be forwarned that some of those hit 0db as well in spots.
